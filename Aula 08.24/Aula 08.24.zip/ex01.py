import math

x = int(input("Insira um número inteiro positivo: "))

if x > 0:
    print("A raíz quadrada de", x, "é", math.sqrt(x))

else:
    print("Número inválido")
