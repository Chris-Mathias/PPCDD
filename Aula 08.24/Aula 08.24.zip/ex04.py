gabarito = []
respostaAluno = []
numQuest = int(input("Insira o número de questões: "))
continuar = ""
acertos = 0

for i in range(numQuest):
    resposta = input("Insira a resposta da questão %d: " % (i + 1)).upper()

    while resposta not in ['A', 'B', 'C', 'D', 'E']:
        print("Alternativa inválida")
        resposta = input("Insira a resposta da questão %d: " % (i + 1)).upper()
        
    gabarito.append(resposta)

while continuar != "n":

    for i in range(numQuest):
        resposta = input("Insira a resposta do aluno da questão %d: " % (i + 1)).upper()

        while resposta not in ['A', 'B', 'C', 'D', 'E']:
            print("Alternativa inválida")
            resposta = input("Insira a resposta do aluno da questão %d: " % (i + 1)).upper()
            
        respostaAluno.append(resposta)

    for i in range(numQuest):

        if respostaAluno[i] == gabarito[i]:
            acertos += 1

    print("O aluno acertou %d questões" % (acertos))

    respostaAluno = []
    acertos = 0

    continuar = input("Deseja continuar corrigindo? (S/n) ").lower()
