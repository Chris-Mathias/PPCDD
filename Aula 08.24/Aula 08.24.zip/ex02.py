x = int(input("Insira um número inteiro: "))

if x % 2 == 0:
    print(x, "é par")

else:
    print(x, " é ímpar")